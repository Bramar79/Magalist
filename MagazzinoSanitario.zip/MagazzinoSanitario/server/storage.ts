import { 
  medicalSupplies, 
  restockingLists, 
  restockingListItems,
  type MedicalSupply, 
  type InsertMedicalSupply,
  type RestockingList,
  type InsertRestockingList,
  type RestockingListItem,
  type InsertRestockingListItem,
  type MedicalSupplyWithStatus,
  type RestockingListWithItems
} from "@shared/schema";
import { db } from "./db";
import { eq, and, ilike, or, inArray } from "drizzle-orm";

export interface IStorage {
  // Medical Supplies
  getAllMedicalSupplies(): Promise<MedicalSupplyWithStatus[]>;
  getMedicalSupply(id: number): Promise<MedicalSupply | undefined>;
  createMedicalSupply(supply: InsertMedicalSupply): Promise<MedicalSupply>;
  updateMedicalSupply(id: number, supply: Partial<InsertMedicalSupply>): Promise<MedicalSupply>;
  deleteMedicalSupply(id: number): Promise<void>;
  
  // Restocking Lists
  getAllRestockingLists(): Promise<RestockingList[]>;
  getRestockingList(id: number): Promise<RestockingListWithItems | undefined>;
  createRestockingList(list: InsertRestockingList): Promise<RestockingList>;
  deleteRestockingList(id: number): Promise<void>;
  
  // Restocking List Items
  addItemToRestockingList(item: InsertRestockingListItem): Promise<RestockingListItem>;
  removeItemFromRestockingList(listId: number, supplyId: number): Promise<void>;
  updateRestockingListItem(listId: number, supplyId: number, quantity: number): Promise<RestockingListItem>;
  
  // Search and Filter
  searchMedicalSupplies(query: string): Promise<MedicalSupplyWithStatus[]>;
  filterMedicalSupplies(categories: string[], statuses: string[]): Promise<MedicalSupplyWithStatus[]>;
}



export class DatabaseStorage implements IStorage {
  private calculateStatus(supply: MedicalSupply): "available" | "low_stock" | "out_of_stock" {
    if (supply.quantity === 0) return "out_of_stock";
    if (supply.quantity <= supply.minQuantity) return "low_stock";
    return "available";
  }

  private calculateStockPercentage(supply: MedicalSupply): number {
    return Math.round((supply.quantity / supply.maxQuantity) * 100);
  }

  async getAllMedicalSupplies(): Promise<MedicalSupplyWithStatus[]> {
    const supplies = await db.select().from(medicalSupplies);
    return supplies.map(supply => ({
      ...supply,
      status: this.calculateStatus(supply),
      stockPercentage: this.calculateStockPercentage(supply)
    }));
  }

  async getMedicalSupply(id: number): Promise<MedicalSupply | undefined> {
    const [supply] = await db.select().from(medicalSupplies).where(eq(medicalSupplies.id, id));
    return supply || undefined;
  }

  async createMedicalSupply(insertSupply: InsertMedicalSupply): Promise<MedicalSupply> {
    const [supply] = await db
      .insert(medicalSupplies)
      .values(insertSupply)
      .returning();
    return supply;
  }

  async updateMedicalSupply(id: number, updateData: Partial<InsertMedicalSupply>): Promise<MedicalSupply> {
    const [supply] = await db
      .update(medicalSupplies)
      .set(updateData)
      .where(eq(medicalSupplies.id, id))
      .returning();
    return supply;
  }

  async deleteMedicalSupply(id: number): Promise<void> {
    await db.delete(medicalSupplies).where(eq(medicalSupplies.id, id));
  }

  async getAllRestockingLists(): Promise<RestockingList[]> {
    return await db.select().from(restockingLists);
  }

  async getRestockingList(id: number): Promise<RestockingListWithItems | undefined> {
    const [list] = await db.select().from(restockingLists).where(eq(restockingLists.id, id));
    if (!list) return undefined;

    const items = await db
      .select({
        id: restockingListItems.id,
        listId: restockingListItems.listId,
        supplyId: restockingListItems.supplyId,
        requestedQuantity: restockingListItems.requestedQuantity,
        order: restockingListItems.order,
        supply: medicalSupplies
      })
      .from(restockingListItems)
      .innerJoin(medicalSupplies, eq(restockingListItems.supplyId, medicalSupplies.id))
      .where(eq(restockingListItems.listId, id))
      .orderBy(restockingListItems.order);

    return { ...list, items };
  }

  async createRestockingList(insertList: InsertRestockingList): Promise<RestockingList> {
    const [list] = await db
      .insert(restockingLists)
      .values(insertList)
      .returning();
    return list;
  }

  async deleteRestockingList(id: number): Promise<void> {
    await db.delete(restockingListItems).where(eq(restockingListItems.listId, id));
    await db.delete(restockingLists).where(eq(restockingLists.id, id));
  }

  async addItemToRestockingList(insertItem: InsertRestockingListItem): Promise<RestockingListItem> {
    const [item] = await db
      .insert(restockingListItems)
      .values(insertItem)
      .returning();
    return item;
  }

  async removeItemFromRestockingList(listId: number, supplyId: number): Promise<void> {
    await db
      .delete(restockingListItems)
      .where(and(
        eq(restockingListItems.listId, listId),
        eq(restockingListItems.supplyId, supplyId)
      ));
  }

  async updateRestockingListItem(listId: number, supplyId: number, quantity: number): Promise<RestockingListItem> {
    const [item] = await db
      .update(restockingListItems)
      .set({ requestedQuantity: quantity })
      .where(and(
        eq(restockingListItems.listId, listId),
        eq(restockingListItems.supplyId, supplyId)
      ))
      .returning();
    return item;
  }

  async searchMedicalSupplies(query: string): Promise<MedicalSupplyWithStatus[]> {
    const supplies = await db
      .select()
      .from(medicalSupplies)
      .where(or(
        ilike(medicalSupplies.name, `%${query}%`),
        ilike(medicalSupplies.code, `%${query}%`),
        ilike(medicalSupplies.description, `%${query}%`)
      ));
    
    return supplies.map(supply => ({
      ...supply,
      status: this.calculateStatus(supply),
      stockPercentage: this.calculateStockPercentage(supply)
    }));
  }

  async filterMedicalSupplies(categories: string[], statuses: string[]): Promise<MedicalSupplyWithStatus[]> {
    let supplies;
    
    if (categories.length > 0) {
      supplies = await db
        .select()
        .from(medicalSupplies)
        .where(inArray(medicalSupplies.category, categories));
    } else {
      supplies = await db.select().from(medicalSupplies);
    }
    
    const suppliesWithStatus = supplies.map(supply => ({
      ...supply,
      status: this.calculateStatus(supply),
      stockPercentage: this.calculateStockPercentage(supply)
    }));
    
    if (statuses.length > 0) {
      return suppliesWithStatus.filter(supply => statuses.includes(supply.status));
    }
    
    return suppliesWithStatus;
  }
}

export const storage = new DatabaseStorage();
