import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMedicalSupplySchema, insertRestockingListSchema, insertRestockingListItemSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Medical Supplies Routes
  app.get("/api/medical-supplies", async (req, res) => {
    try {
      const { search, categories, statuses } = req.query;
      
      let supplies;
      if (search) {
        supplies = await storage.searchMedicalSupplies(search as string);
      } else if (categories || statuses) {
        const categoryArray = categories ? (categories as string).split(',') : [];
        const statusArray = statuses ? (statuses as string).split(',') : [];
        supplies = await storage.filterMedicalSupplies(categoryArray, statusArray);
      } else {
        supplies = await storage.getAllMedicalSupplies();
      }
      
      res.json(supplies);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch medical supplies" });
    }
  });

  app.get("/api/medical-supplies/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const supply = await storage.getMedicalSupply(id);
      
      if (!supply) {
        return res.status(404).json({ error: "Medical supply not found" });
      }
      
      res.json(supply);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch medical supply" });
    }
  });

  app.post("/api/medical-supplies", async (req, res) => {
    try {
      const validatedData = insertMedicalSupplySchema.parse(req.body);
      const supply = await storage.createMedicalSupply(validatedData);
      res.status(201).json(supply);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create medical supply" });
    }
  });

  app.put("/api/medical-supplies/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertMedicalSupplySchema.partial().parse(req.body);
      const supply = await storage.updateMedicalSupply(id, validatedData);
      res.json(supply);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to update medical supply" });
    }
  });

  app.delete("/api/medical-supplies/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteMedicalSupply(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete medical supply" });
    }
  });

  // Restocking Lists Routes
  app.get("/api/restocking-lists", async (req, res) => {
    try {
      const lists = await storage.getAllRestockingLists();
      res.json(lists);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch restocking lists" });
    }
  });

  app.get("/api/restocking-lists/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const list = await storage.getRestockingList(id);
      
      if (!list) {
        return res.status(404).json({ error: "Restocking list not found" });
      }
      
      res.json(list);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch restocking list" });
    }
  });

  app.post("/api/restocking-lists", async (req, res) => {
    try {
      const validatedData = insertRestockingListSchema.parse(req.body);
      const list = await storage.createRestockingList(validatedData);
      res.status(201).json(list);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create restocking list" });
    }
  });

  app.delete("/api/restocking-lists/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteRestockingList(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete restocking list" });
    }
  });

  // Restocking List Items Routes
  app.post("/api/restocking-lists/:listId/items", async (req, res) => {
    try {
      const listId = parseInt(req.params.listId);
      const validatedData = insertRestockingListItemSchema.parse({
        ...req.body,
        listId
      });
      const item = await storage.addItemToRestockingList(validatedData);
      res.status(201).json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to add item to restocking list" });
    }
  });

  app.delete("/api/restocking-lists/:listId/items/:supplyId", async (req, res) => {
    try {
      const listId = parseInt(req.params.listId);
      const supplyId = parseInt(req.params.supplyId);
      await storage.removeItemFromRestockingList(listId, supplyId);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to remove item from restocking list" });
    }
  });

  app.put("/api/restocking-lists/:listId/items/:supplyId", async (req, res) => {
    try {
      const listId = parseInt(req.params.listId);
      const supplyId = parseInt(req.params.supplyId);
      const { requestedQuantity } = req.body;
      
      if (typeof requestedQuantity !== 'number' || requestedQuantity <= 0) {
        return res.status(400).json({ error: "Invalid quantity" });
      }
      
      const item = await storage.updateRestockingListItem(listId, supplyId, requestedQuantity);
      res.json(item);
    } catch (error) {
      res.status(500).json({ error: "Failed to update item in restocking list" });
    }
  });

  // Inventory Stats Route
  app.get("/api/inventory-stats", async (req, res) => {
    try {
      const supplies = await storage.getAllMedicalSupplies();
      const stats = {
        total: supplies.length,
        available: supplies.filter(s => s.status === "available").length,
        lowStock: supplies.filter(s => s.status === "low_stock").length,
        outOfStock: supplies.filter(s => s.status === "out_of_stock").length
      };
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch inventory stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
