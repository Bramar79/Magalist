import { db } from "./db";
import { medicalSupplies, type InsertMedicalSupply } from "@shared/schema";

const sampleSupplies: InsertMedicalSupply[] = [
  {
    name: "Kit Chirurgico Sterile",
    code: "CHI-001",
    category: "surgical",
    quantity: 45,
    minQuantity: 10,
    maxQuantity: 100,
    imageUrl: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&h=200",
    description: "Kit completo per interventi chirurgici sterili"
  },
  {
    name: "Mascherine Chirurgiche",
    code: "DPI-005",
    category: "ppe",
    quantity: 12,
    minQuantity: 50,
    maxQuantity: 500,
    imageUrl: "https://images.unsplash.com/photo-1584017911766-d451b3d0e843?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&h=200",
    description: "Mascherine chirurgiche monouso certificate"
  },
  {
    name: "Antibiotici Generici",
    code: "FAR-023",
    category: "medication",
    quantity: 0,
    minQuantity: 20,
    maxQuantity: 200,
    imageUrl: "https://images.unsplash.com/photo-1471864190281-a93a3070b6de?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&h=200",
    description: "Antibiotici ad ampio spettro"
  },
  {
    name: "Kit Diagnostico",
    code: "DIA-008",
    category: "diagnostic",
    quantity: 23,
    minQuantity: 5,
    maxQuantity: 50,
    imageUrl: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&h=200",
    description: "Strumenti per diagnostica medica"
  },
  {
    name: "Siringhe Monouso",
    code: "CHI-015",
    category: "surgical",
    quantity: 8,
    minQuantity: 30,
    maxQuantity: 300,
    imageUrl: "https://images.unsplash.com/photo-1581595220892-b0739db3ba8c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&h=200",
    description: "Siringhe sterili monouso varie misure"
  },
  {
    name: "Guanti Nitrile",
    code: "DPI-012",
    category: "ppe",
    quantity: 156,
    minQuantity: 100,
    maxQuantity: 1000,
    imageUrl: "https://images.unsplash.com/photo-1583947215259-38e31be8751f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&h=200",
    description: "Guanti in nitrile senza polvere"
  },
  {
    name: "Defibrillatore AED",
    code: "EMG-003",
    category: "emergency",
    quantity: 5,
    minQuantity: 2,
    maxQuantity: 10,
    imageUrl: "https://images.unsplash.com/photo-1581594693702-fbdc51b2763b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&h=200",
    description: "Defibrillatore automatico esterno"
  },
  {
    name: "Soluzioni Fisiologiche",
    code: "FAR-045",
    category: "medication",
    quantity: 18,
    minQuantity: 50,
    maxQuantity: 200,
    imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&h=200",
    description: "Soluzioni fisiologiche per infusione"
  }
];

async function seedDatabase() {
  try {
    console.log("🌱 Seeding database with sample medical supplies...");
    
    // Check if data already exists
    const existingSupplies = await db.select().from(medicalSupplies);
    if (existingSupplies.length > 0) {
      console.log("✅ Database already contains data, skipping seed");
      return;
    }
    
    // Insert sample data
    await db.insert(medicalSupplies).values(sampleSupplies);
    
    console.log(`✅ Successfully seeded ${sampleSupplies.length} medical supplies`);
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    throw error;
  }
}

// Auto-run when script is executed directly
seedDatabase().then(() => process.exit(0)).catch(() => process.exit(1));

export { seedDatabase };