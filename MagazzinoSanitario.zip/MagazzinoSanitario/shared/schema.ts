import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const medicalSupplies = pgTable("medical_supplies", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  code: text("code").notNull().unique(),
  category: text("category").notNull(),
  quantity: integer("quantity").notNull().default(0),
  minQuantity: integer("min_quantity").notNull().default(10),
  maxQuantity: integer("max_quantity").notNull().default(100),
  imageUrl: text("image_url"),
  description: text("description"),
});

export const restockingLists = pgTable("restocking_lists", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  status: text("status").notNull().default("draft"), // draft, sent, completed
});

export const restockingListItems = pgTable("restocking_list_items", {
  id: serial("id").primaryKey(),
  listId: integer("list_id").references(() => restockingLists.id).notNull(),
  supplyId: integer("supply_id").references(() => medicalSupplies.id).notNull(),
  requestedQuantity: integer("requested_quantity").notNull(),
  order: integer("order").notNull().default(0),
});

export const insertMedicalSupplySchema = createInsertSchema(medicalSupplies).omit({
  id: true,
});

export const insertRestockingListSchema = createInsertSchema(restockingLists).omit({
  id: true,
  createdAt: true,
});

export const insertRestockingListItemSchema = createInsertSchema(restockingListItems).omit({
  id: true,
});

export type MedicalSupply = typeof medicalSupplies.$inferSelect;
export type InsertMedicalSupply = z.infer<typeof insertMedicalSupplySchema>;
export type RestockingList = typeof restockingLists.$inferSelect;
export type InsertRestockingList = z.infer<typeof insertRestockingListSchema>;
export type RestockingListItem = typeof restockingListItems.$inferSelect;
export type InsertRestockingListItem = z.infer<typeof insertRestockingListItemSchema>;

export type MedicalSupplyWithStatus = MedicalSupply & {
  status: "available" | "low_stock" | "out_of_stock";
  stockPercentage: number;
};

export type RestockingListWithItems = RestockingList & {
  items: (RestockingListItem & { supply: MedicalSupply })[];
};
