import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import InventoryHeader from "@/components/inventory-header";
import InventoryFilters from "@/components/inventory-filters";
import InventoryStats from "@/components/inventory-stats";
import InventoryGrid from "@/components/inventory-grid";
import RestockingModal from "@/components/restocking-modal";
import { type MedicalSupplyWithStatus } from "@shared/schema";

export default function InventoryPage() {
  const [selectedItems, setSelectedItems] = useState<Set<number>>(new Set());
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedStatuses, setSelectedStatuses] = useState<string[]>([]);
  const [showRestockingModal, setShowRestockingModal] = useState(false);

  const { data: supplies = [], isLoading, error } = useQuery<MedicalSupplyWithStatus[]>({
    queryKey: ['/api/medical-supplies', { 
      search: searchQuery || undefined,
      categories: selectedCategories.length > 0 ? selectedCategories.join(',') : undefined,
      statuses: selectedStatuses.length > 0 ? selectedStatuses.join(',') : undefined
    }],
    queryFn: async ({ queryKey }) => {
      const [url, params] = queryKey;
      const searchParams = new URLSearchParams();
      
      if (params?.search) searchParams.append('search', params.search);
      if (params?.categories) searchParams.append('categories', params.categories);
      if (params?.statuses) searchParams.append('statuses', params.statuses);
      
      const queryString = searchParams.toString();
      const response = await fetch(`${url}${queryString ? `?${queryString}` : ''}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch supplies');
      }
      
      return response.json();
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const handleItemSelect = (supplyId: number, selected: boolean) => {
    const newSelected = new Set(selectedItems);
    if (selected) {
      newSelected.add(supplyId);
    } else {
      newSelected.delete(supplyId);
    }
    setSelectedItems(newSelected);
  };

  const handleSelectAll = (selected: boolean) => {
    if (selected) {
      setSelectedItems(new Set(supplies.map(s => s.id)));
    } else {
      setSelectedItems(new Set());
    }
  };

  const handleCreateRestockingList = () => {
    if (selectedItems.size > 0) {
      setShowRestockingModal(true);
    }
  };

  const handleRestockingListCreated = () => {
    setSelectedItems(new Set());
    setShowRestockingModal(false);
  };

  const selectedSupplies = supplies.filter(s => selectedItems.has(s.id));

  if (error) {
    return (
      <div className="min-h-screen bg-[var(--bg-light)] flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-[var(--status-red)] mb-4">Errore nel caricamento</h2>
          <p className="text-[var(--text-secondary)]">
            Si è verificato un errore durante il caricamento dell'inventario.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--bg-light)]">
      <InventoryHeader 
        selectedCount={selectedItems.size}
        onCreateRestockingList={handleCreateRestockingList}
      />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex gap-6">
          <InventoryFilters
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            selectedCategories={selectedCategories}
            onCategoriesChange={setSelectedCategories}
            selectedStatuses={selectedStatuses}
            onStatusesChange={setSelectedStatuses}
            selectedCount={selectedItems.size}
            onCreateRestockingList={handleCreateRestockingList}
          />
          
          <div className="flex-1">
            <InventoryStats />
            
            <InventoryGrid
              supplies={supplies}
              selectedItems={selectedItems}
              onItemSelect={handleItemSelect}
              onSelectAll={handleSelectAll}
              isLoading={isLoading}
            />
          </div>
        </div>
      </div>

      <RestockingModal
        isOpen={showRestockingModal}
        onClose={() => setShowRestockingModal(false)}
        selectedSupplies={selectedSupplies}
        onListCreated={handleRestockingListCreated}
      />
    </div>
  );
}
