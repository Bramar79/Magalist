import { Hospital, Plus, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";

interface InventoryHeaderProps {
  selectedCount: number;
  onCreateRestockingList: () => void;
}

export default function InventoryHeader({ selectedCount, onCreateRestockingList }: InventoryHeaderProps) {
  return (
    <header className="surface-card border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Hospital className="text-[var(--medical-blue)] text-2xl mr-3" />
            <h1 className="text-xl font-semibold text-primary">Sistema Magazzino Ospedaliero</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button 
              onClick={onCreateRestockingList}
              disabled={selectedCount === 0}
              className="medical-btn-primary"
            >
              <Plus className="mr-2 h-4 w-4" />
              Nuovo Ordine
            </Button>
            <div className="relative">
              <Bell className="text-secondary text-xl cursor-pointer hover:text-primary" />
              <span className="absolute -top-2 -right-2 bg-[var(--status-red)] text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                3
              </span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
