import { Grid, List, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { getStatusText } from "@/lib/utils";
import { type MedicalSupplyWithStatus } from "@shared/schema";

interface InventoryGridProps {
  supplies: MedicalSupplyWithStatus[];
  selectedItems: Set<number>;
  onItemSelect: (supplyId: number, selected: boolean) => void;
  onSelectAll: (selected: boolean) => void;
  isLoading: boolean;
}

export default function InventoryGrid({
  supplies,
  selectedItems,
  onItemSelect,
  onSelectAll,
  isLoading
}: InventoryGridProps) {
  
  const allSelected = supplies.length > 0 && supplies.every(s => selectedItems.has(s.id));
  const someSelected = supplies.some(s => selectedItems.has(s.id));

  if (isLoading) {
    return (
      <div className="surface-card rounded-lg">
        <div className="px-6 py-4 border-b border-[var(--border)]">
          <div className="flex justify-between items-center">
            <h2 className="text-lg font-semibold text-primary">Inventario Presidi</h2>
            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="sm">
                <Grid className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <List className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Download className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="border border-[var(--border)] rounded-lg p-4 animate-pulse">
                <div className="flex items-center justify-between mb-3">
                  <div className="w-4 h-4 bg-gray-200 rounded" />
                  <div className="w-16 h-6 bg-gray-200 rounded-full" />
                </div>
                <div className="w-full h-32 bg-gray-200 rounded-md mb-3" />
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-1" />
                <div className="h-3 bg-gray-200 rounded w-1/2 mb-2" />
                <div className="flex justify-between items-center">
                  <div className="h-3 bg-gray-200 rounded w-16" />
                  <div className="h-4 bg-gray-200 rounded w-8" />
                </div>
                <div className="w-full h-2 bg-gray-200 rounded-full mt-2" />
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="surface-card rounded-lg">
      <div className="px-6 py-4 border-b border-[var(--border)]">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <h2 className="text-lg font-semibold text-primary">Inventario Presidi</h2>
            <div className="flex items-center space-x-2">
              <Checkbox
                checked={allSelected}
                onCheckedChange={onSelectAll}
                className={someSelected && !allSelected ? "data-[state=checked]:bg-orange-500" : ""}
              />
              <span className="text-sm text-secondary">
                {selectedItems.size > 0 ? `${selectedItems.size} selezionati` : "Seleziona tutto"}
              </span>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm">
              <Grid className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <List className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6">
        {supplies.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">📦</div>
            <h3 className="text-lg font-semibold text-primary mb-2">Nessun presidio trovato</h3>
            <p className="text-secondary">
              Prova a modificare i filtri o il termine di ricerca.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {supplies.map((supply) => (
              <div
                key={supply.id}
                className="border border-[var(--border)] rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => onItemSelect(supply.id, !selectedItems.has(supply.id))}
              >
                <div className="flex items-center justify-between mb-3">
                  <Checkbox
                    checked={selectedItems.has(supply.id)}
                    onCheckedChange={(checked) => onItemSelect(supply.id, checked as boolean)}
                    onClick={(e) => e.stopPropagation()}
                  />
                  <Badge 
                    className={`text-xs ${
                      supply.status === "available" ? "status-available" :
                      supply.status === "low_stock" ? "status-low-stock" :
                      "status-out-of-stock"
                    }`}
                  >
                    {getStatusText(supply.status)}
                  </Badge>
                </div>
                
                <img
                  src={supply.imageUrl || "/api/placeholder/300/200"}
                  alt={supply.name}
                  className="w-full h-32 object-cover rounded-md mb-3"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='200' viewBox='0 0 300 200'%3E%3Crect width='300' height='200' fill='%23f3f4f6'/%3E%3Ctext x='150' y='100' text-anchor='middle' fill='%236b7280' font-family='Arial' font-size='14'%3EImmagine non disponibile%3C/text%3E%3C/svg%3E";
                  }}
                />
                
                <h3 className="font-medium text-primary mb-1">{supply.name}</h3>
                <p className="text-sm text-secondary mb-2">Codice: {supply.code}</p>
                
                <div className="flex justify-between items-center">
                  <span className="text-sm text-secondary">Quantità:</span>
                  <span className="font-semibold text-primary">{supply.quantity}</span>
                </div>
                
                <div className="mt-2">
                  <Progress 
                    value={supply.stockPercentage} 
                    className="h-2"
                    indicatorClassName={
                      supply.status === "available" ? "bg-[var(--status-green)]" :
                      supply.status === "low_stock" ? "bg-[var(--status-orange)]" :
                      "bg-[var(--status-red)]"
                    }
                  />
                </div>
              </div>
            ))}
          </div>
        )}
        
        {supplies.length > 0 && (
          <div className="flex justify-between items-center mt-6 pt-4 border-t border-[var(--border)]">
            <div className="text-sm text-secondary">
              Mostra 1-{supplies.length} di {supplies.length} articoli
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">Precedente</Button>
              <Button size="sm" className="medical-btn-primary">1</Button>
              <Button variant="outline" size="sm">2</Button>
              <Button variant="outline" size="sm">3</Button>
              <Button variant="outline" size="sm">Successivo</Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
