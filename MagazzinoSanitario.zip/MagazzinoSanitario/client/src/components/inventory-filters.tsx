import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { getCategoryText, getStatusText } from "@/lib/utils";

interface InventoryFiltersProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedCategories: string[];
  onCategoriesChange: (categories: string[]) => void;
  selectedStatuses: string[];
  onStatusesChange: (statuses: string[]) => void;
  selectedCount: number;
  onCreateRestockingList: () => void;
}

const categories = ["surgical", "medication", "ppe", "diagnostic", "emergency"];
const statuses = ["available", "low_stock", "out_of_stock"];

export default function InventoryFilters({
  searchQuery,
  onSearchChange,
  selectedCategories,
  onCategoriesChange,
  selectedStatuses,
  onStatusesChange,
  selectedCount,
  onCreateRestockingList
}: InventoryFiltersProps) {
  
  const handleCategoryChange = (category: string, checked: boolean) => {
    if (checked) {
      onCategoriesChange([...selectedCategories, category]);
    } else {
      onCategoriesChange(selectedCategories.filter(c => c !== category));
    }
  };

  const handleStatusChange = (status: string, checked: boolean) => {
    if (checked) {
      onStatusesChange([...selectedStatuses, status]);
    } else {
      onStatusesChange(selectedStatuses.filter(s => s !== status));
    }
  };

  return (
    <div className="w-64 surface-card rounded-lg p-6 h-fit">
      <h2 className="text-lg font-semibold text-primary mb-4">Filtri</h2>
      
      {/* Search Bar */}
      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-secondary" />
          <Input
            type="text"
            placeholder="Cerca presidi..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Category Filters */}
      <div className="mb-6">
        <h3 className="text-sm font-medium text-primary mb-3">Categorie</h3>
        <div className="space-y-2">
          {categories.map((category) => (
            <div key={category} className="flex items-center space-x-2">
              <Checkbox
                id={category}
                checked={selectedCategories.includes(category)}
                onCheckedChange={(checked) => handleCategoryChange(category, checked as boolean)}
              />
              <label
                htmlFor={category}
                className="text-sm text-secondary cursor-pointer"
              >
                {getCategoryText(category)}
              </label>
            </div>
          ))}
        </div>
      </div>

      {/* Status Filters */}
      <div className="mb-6">
        <h3 className="text-sm font-medium text-primary mb-3">Stato Scorte</h3>
        <div className="space-y-2">
          {statuses.map((status) => (
            <div key={status} className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id={status}
                  checked={selectedStatuses.includes(status)}
                  onCheckedChange={(checked) => handleStatusChange(status, checked as boolean)}
                />
                <label
                  htmlFor={status}
                  className="text-sm text-secondary cursor-pointer"
                >
                  {getStatusText(status)}
                </label>
              </div>
              <div className={`w-2 h-2 rounded-full ${
                status === "available" ? "bg-[var(--status-green)]" :
                status === "low_stock" ? "bg-[var(--status-orange)]" :
                "bg-[var(--status-red)]"
              }`} />
            </div>
          ))}
        </div>
      </div>

      {/* Selected Items Counter */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-[var(--medical-blue)]">Articoli selezionati</span>
          <span className="text-lg font-bold text-[var(--medical-blue)]">{selectedCount}</span>
        </div>
        <Button
          onClick={onCreateRestockingList}
          disabled={selectedCount === 0}
          className="w-full mt-3 medical-btn-primary text-sm"
        >
          Crea Lista Rifornimenti
        </Button>
      </div>
    </div>
  );
}
