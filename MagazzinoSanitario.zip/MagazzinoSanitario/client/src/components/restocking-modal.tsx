import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { X, GripVertical, Trash2, Save, Printer } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { type MedicalSupplyWithStatus } from "@shared/schema";

interface RestockingModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedSupplies: MedicalSupplyWithStatus[];
  onListCreated: () => void;
}

interface RestockingItem {
  supply: MedicalSupplyWithStatus;
  requestedQuantity: number;
}

export default function RestockingModal({
  isOpen,
  onClose,
  selectedSupplies,
  onListCreated
}: RestockingModalProps) {
  const [listName, setListName] = useState("");
  const [items, setItems] = useState<RestockingItem[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Initialize items when modal opens
  useState(() => {
    if (isOpen && selectedSupplies.length > 0) {
      const initialItems = selectedSupplies.map(supply => ({
        supply,
        requestedQuantity: Math.max(supply.minQuantity - supply.quantity, 10)
      }));
      setItems(initialItems);
    }
  }, [isOpen, selectedSupplies]);

  const createListMutation = useMutation({
    mutationFn: async (data: { name: string; items: RestockingItem[] }) => {
      // Create the list
      const listResponse = await apiRequest("POST", "/api/restocking-lists", {
        name: data.name,
        status: "draft"
      });
      
      const list = await listResponse.json();
      
      // Add items to the list
      for (let i = 0; i < data.items.length; i++) {
        const item = data.items[i];
        await apiRequest("POST", `/api/restocking-lists/${list.id}/items`, {
          supplyId: item.supply.id,
          requestedQuantity: item.requestedQuantity,
          order: i
        });
      }
      
      return list;
    },
    onSuccess: () => {
      toast({
        title: "Lista creata con successo",
        description: "La lista di rifornimenti è stata creata correttamente."
      });
      queryClient.invalidateQueries({ queryKey: ['/api/restocking-lists'] });
      onListCreated();
      handleClose();
    },
    onError: (error) => {
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante la creazione della lista.",
        variant: "destructive"
      });
    }
  });

  const handleClose = () => {
    setListName("");
    setItems([]);
    onClose();
  };

  const handleQuantityChange = (supplyId: number, quantity: number) => {
    setItems(items.map(item => 
      item.supply.id === supplyId 
        ? { ...item, requestedQuantity: Math.max(1, quantity) }
        : item
    ));
  };

  const handleRemoveItem = (supplyId: number) => {
    setItems(items.filter(item => item.supply.id !== supplyId));
  };

  const handleSave = () => {
    if (!listName.trim()) {
      toast({
        title: "Nome richiesto",
        description: "Inserisci un nome per la lista di rifornimenti.",
        variant: "destructive"
      });
      return;
    }

    if (items.length === 0) {
      toast({
        title: "Nessun articolo",
        description: "Aggiungi almeno un articolo alla lista.",
        variant: "destructive"
      });
      return;
    }

    createListMutation.mutate({ name: listName, items });
  };

  const handlePrint = () => {
    const printContent = `
      <html>
        <head>
          <title>Lista Rifornimenti - ${listName}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            table { width: 100%; border-collapse: collapse; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            .header { margin-bottom: 20px; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Lista Rifornimenti</h1>
            <h2>${listName}</h2>
            <p>Data: ${new Date().toLocaleDateString('it-IT')}</p>
          </div>
          <table>
            <thead>
              <tr>
                <th>Codice</th>
                <th>Nome</th>
                <th>Quantità Richiesta</th>
                <th>Quantità Attuale</th>
              </tr>
            </thead>
            <tbody>
              ${items.map(item => `
                <tr>
                  <td>${item.supply.code}</td>
                  <td>${item.supply.name}</td>
                  <td>${item.requestedQuantity}</td>
                  <td>${item.supply.quantity}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>Lista Rifornimenti</span>
            <Button variant="ghost" size="sm" onClick={handleClose}>
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <Input
              placeholder="Nome lista rifornimenti..."
              value={listName}
              onChange={(e) => setListName(e.target.value)}
              className="w-full"
            />
          </div>
          
          <div className="max-h-96 overflow-y-auto">
            {items.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-secondary">Nessun articolo selezionato</p>
              </div>
            ) : (
              <div className="space-y-3">
                {items.map((item) => (
                  <div
                    key={item.supply.id}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                  >
                    <div className="flex items-center">
                      <GripVertical className="h-4 w-4 text-secondary mr-3" />
                      <div>
                        <h4 className="font-medium text-primary">{item.supply.name}</h4>
                        <p className="text-sm text-secondary">Codice: {item.supply.code}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Input
                        type="number"
                        value={item.requestedQuantity}
                        onChange={(e) => handleQuantityChange(item.supply.id, parseInt(e.target.value) || 0)}
                        className="w-16 text-center"
                        min="1"
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRemoveItem(item.supply.id)}
                        className="text-[var(--status-red)] hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
        
        <div className="flex justify-end space-x-3 pt-4 border-t">
          <Button variant="outline" onClick={handleClose}>
            Annulla
          </Button>
          <Button
            variant="outline"
            onClick={handlePrint}
            disabled={items.length === 0 || !listName.trim()}
          >
            <Printer className="mr-2 h-4 w-4" />
            Stampa
          </Button>
          <Button
            onClick={handleSave}
            disabled={createListMutation.isPending || items.length === 0 || !listName.trim()}
            className="medical-btn-primary"
          >
            {createListMutation.isPending ? (
              <>Salvataggio...</>
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" />
                Salva Lista
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
