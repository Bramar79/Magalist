import { useQuery } from "@tanstack/react-query";
import { CheckCircle, AlertTriangle, XCircle, Package } from "lucide-react";

interface InventoryStats {
  total: number;
  available: number;
  lowStock: number;
  outOfStock: number;
}

export default function InventoryStats() {
  const { data: stats, isLoading } = useQuery<InventoryStats>({
    queryKey: ['/api/inventory-stats'],
    queryFn: async () => {
      const response = await fetch('/api/inventory-stats');
      if (!response.ok) {
        throw new Error('Failed to fetch stats');
      }
      return response.json();
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="surface-card rounded-lg p-6 animate-pulse">
            <div className="flex items-center">
              <div className="p-3 bg-gray-100 rounded-lg">
                <div className="w-6 h-6 bg-gray-200 rounded" />
              </div>
              <div className="ml-4">
                <div className="h-4 bg-gray-200 rounded w-20 mb-2" />
                <div className="h-8 bg-gray-200 rounded w-12" />
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (!stats) {
    return null;
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
      <div className="surface-card rounded-lg p-6">
        <div className="flex items-center">
          <div className="p-3 bg-green-100 rounded-lg">
            <CheckCircle className="text-[var(--status-green)] text-xl" />
          </div>
          <div className="ml-4">
            <p className="text-sm text-secondary">Disponibili</p>
            <p className="text-2xl font-bold text-primary">{stats.available}</p>
          </div>
        </div>
      </div>
      
      <div className="surface-card rounded-lg p-6">
        <div className="flex items-center">
          <div className="p-3 bg-orange-100 rounded-lg">
            <AlertTriangle className="text-[var(--status-orange)] text-xl" />
          </div>
          <div className="ml-4">
            <p className="text-sm text-secondary">Scorte Basse</p>
            <p className="text-2xl font-bold text-primary">{stats.lowStock}</p>
          </div>
        </div>
      </div>
      
      <div className="surface-card rounded-lg p-6">
        <div className="flex items-center">
          <div className="p-3 bg-red-100 rounded-lg">
            <XCircle className="text-[var(--status-red)] text-xl" />
          </div>
          <div className="ml-4">
            <p className="text-sm text-secondary">Esauriti</p>
            <p className="text-2xl font-bold text-primary">{stats.outOfStock}</p>
          </div>
        </div>
      </div>
      
      <div className="surface-card rounded-lg p-6">
        <div className="flex items-center">
          <div className="p-3 bg-blue-100 rounded-lg">
            <Package className="text-[var(--medical-blue)] text-xl" />
          </div>
          <div className="ml-4">
            <p className="text-sm text-secondary">Totale Articoli</p>
            <p className="text-2xl font-bold text-primary">{stats.total}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
