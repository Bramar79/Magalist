import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const formatDate = (date: Date | string) => {
  return new Date(date).toLocaleDateString("it-IT", {
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
};

export const getStatusColor = (status: string) => {
  switch (status) {
    case "available":
      return "bg-green-500";
    case "low_stock":
      return "bg-orange-500";
    case "out_of_stock":
      return "bg-red-500";
    default:
      return "bg-gray-500";
  }
};

export const getStatusText = (status: string) => {
  switch (status) {
    case "available":
      return "Disponibile";
    case "low_stock":
      return "Scorte Basse";
    case "out_of_stock":
      return "Esaurito";
    default:
      return "Sconosciuto";
  }
};

export const getCategoryText = (category: string) => {
  switch (category) {
    case "surgical":
      return "Chirurgico";
    case "medication":
      return "Farmaci";
    case "ppe":
      return "DPI";
    case "diagnostic":
      return "Diagnostica";
    case "emergency":
      return "Emergenza";
    default:
      return category;
  }
};
